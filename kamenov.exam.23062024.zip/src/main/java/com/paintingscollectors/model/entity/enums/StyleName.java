package com.paintingscollectors.model.entity.enums;

public enum StyleName {
    IMPRESSIONISM, ABSTRACT, EXPRESSIONISM, SURREALISM, REALISM
}
